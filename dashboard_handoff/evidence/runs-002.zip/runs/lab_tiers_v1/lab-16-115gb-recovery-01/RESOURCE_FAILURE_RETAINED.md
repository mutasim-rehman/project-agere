# Resource failure retained

Accuracy continuation only; source swap failure forbids an uninterrupted no-swap deployment-pass claim. Every completed frozen prefix case is reused, without quality selection. Models/context/prompts/scores unchanged.
