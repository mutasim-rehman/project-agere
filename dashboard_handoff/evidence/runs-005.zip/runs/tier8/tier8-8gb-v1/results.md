# 8 GB tier result

Study `tier8-8gb-v1`. Host job cap is the 8 GB tier budget, 6.4 GB nominal.

Frozen SAS: `naive_sas`. The staged prompt did not beat the untouched 7B on dev. The untouched model stays.
Frozen MAS: `naive_mas`. Hardened team did not improve the dev floor. The naive team remains the frozen MAS.

## Dev
- naive_sas: status complete, valid JSON 1.0, invention 0.78, mismatch recall 0.0, grounding 0.8178506375227687, refusal 0.0, tags {'S6': 117}
- naive_mas: status complete, valid JSON 0.62, invention 0.9139784946236559, mismatch recall 0.0, grounding 0.37158469945355194, refusal 0.0, tags {'M2': 57, 'M3': 85, 'M7': 8}
- hardened_sas_base: status complete, valid JSON 0.19333333333333333, invention 1.0, mismatch recall 0.2, grounding 0.10746812386156648, refusal 0.0, tags {'S3': 121, 'S6': 29}
- hardened_mas: status complete, valid JSON 0.0, invention None, mismatch recall 0.0, grounding 0.0, refusal 0.0, tags {'M2': 150}

## Held-out test, pooled KYC 100 and credit 75
- SAS invention 0.7142857142857143, mismatch recall 0.0, grounding 0.84399375975039
- MAS invention 0.8018018018018018, mismatch recall 0.0, grounding 0.36349453978159124

Invention is lower-better. Mismatch recall is higher-better. Greedy decoding, temperature 0, seed 42. Extra seeds would repeat the same outputs.

## FRAMES control
- {"sas": {"n": 100, "exact_match": 0.01}, "mas": {"n": 100, "exact_match": 0.02}, "note": "Closed-book control. A team win here does not override the KYC and credit invention result."}
