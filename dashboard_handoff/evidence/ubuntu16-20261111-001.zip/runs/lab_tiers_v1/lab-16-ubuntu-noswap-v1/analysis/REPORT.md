# Offline lab evaluation summary

All counts are over the complete paired dataset, including withheld cases.

| Job | Correct reported | Wrong reported | Withheld | Correct raw | Peak RSS GB |
|---|---:|---:|---:|---:|---:|
| tier16-mas-direct_control | 0 | 5 | 155 | 0 | 10.934 |
| tier16-mas-primary | 5 | 3 | 152 | 5 | 10.946 |
| tier16-mas-repair_ablation | 5 | 3 | 152 | 5 | 10.946 |
| tier16-sas-direct_control | 50 | 66 | 44 | 14 | 10.070 |
| tier16-sas-primary | 78 | 48 | 34 | 38 | 10.075 |
| tier16-sas-repair_ablation | 79 | 50 | 31 | 38 | 10.087 |

Paired report-level intervals and all audit hashes: `analysis/summary.json`.

No automatic proof of H0, equivalence, a novel method or deployment safety. See frozen manifest for scope/limitations.
