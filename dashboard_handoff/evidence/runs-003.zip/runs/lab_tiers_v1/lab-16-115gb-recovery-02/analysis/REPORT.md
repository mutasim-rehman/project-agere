# Offline lab evaluation summary

**RESOURCE FAILURE RETAINED: accuracy continuation; NOT a clean uninterrupted no-swap deployment pass.**

Accuracy continuation only; source swap failure forbids an uninterrupted no-swap deployment-pass claim. Every completed frozen prefix case is reused, without quality selection. Models/context/prompts/scores unchanged.

All counts are over the complete paired dataset, including withheld cases.

| Job | Correct reported | Wrong reported | Withheld | Correct raw | Peak RSS GB |
|---|---:|---:|---:|---:|---:|
| tier16-mas-direct_control | 0 | 5 | 155 | 0 | 10.901 |
| tier16-mas-primary | 5 | 3 | 152 | 5 | 10.929 |
| tier16-mas-repair_ablation | 5 | 3 | 152 | 5 | 10.913 |
| tier16-sas-direct_control | 50 | 66 | 44 | 14 | 10.040 |
| tier16-sas-primary | 78 | 48 | 34 | 38 | 10.062 |
| tier16-sas-repair_ablation | 79 | 50 | 31 | 38 | 10.074 |

Paired report-level intervals and all audit hashes: `analysis/summary.json`.

No automatic proof of H0, equivalence, a novel method or deployment safety. See frozen manifest for scope/limitations.
